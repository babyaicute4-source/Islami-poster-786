import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const AsgarApp());

class AsgarApp extends StatelessWidget {
  const AsgarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Asgar App',
    theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
    home: const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  bool loading = false;
  Future<void> enter() async {
    if (name.text.trim().isEmpty) return;
    setState(() => loading = true);
    final p = await SharedPreferences.getInstance();
    await p.setString('name', name.text.trim());
    await p.setString('email', email.text.trim());
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.person_pin, size: 80),
        const SizedBox(height: 12),
        const Text('Asgar App', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        const SizedBox(height: 30),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Your name', border: OutlineInputBorder())),
        const SizedBox(height: 14),
        TextField(controller: email, decoration: const InputDecoration(labelText: 'Email (optional)', border: OutlineInputBorder())),
        const SizedBox(height: 20),
        FilledButton(onPressed: loading ? null : enter, child: Text(loading ? 'Please wait...' : 'Create Profile')),
      ]),
    )),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String userName = 'User', email = '';
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    setState(() { userName = p.getString('name') ?? 'User'; email = p.getString('email') ?? ''; });
  }
  Future<void> editProfile() async {
    final c = TextEditingController(text: userName);
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Edit Profile'),
      content: TextField(controller: c, decoration: const InputDecoration(labelText: 'Name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () async {
          final p = await SharedPreferences.getInstance();
          await p.setString('name', c.text.trim().isEmpty ? userName : c.text.trim());
          if (mounted) { Navigator.pop(context); load(); }
        }, child: const Text('Save')),
      ],
    ));
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Home')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Row(children: [
        const CircleAvatar(radius: 36, child: Icon(Icons.person, size: 38)),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(userName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          if (email.isNotEmpty) Text(email),
        ])),
        IconButton(onPressed: editProfile, icon: const Icon(Icons.edit)),
      ]))),
      const SizedBox(height: 20),
      const Card(child: ListTile(leading: Icon(Icons.home), title: Text('Home'), subtitle: Text('Your app dashboard'))),
      const Card(child: ListTile(leading: Icon(Icons.people), title: Text('Profiles'), subtitle: Text('More social features can be added here'))),
    ]),
  );
}
