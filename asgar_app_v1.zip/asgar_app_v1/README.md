# Asgar App v1
Basic Flutter starter with:
- User name/email profile
- Local profile saving
- Home screen
- Edit profile
- Ready for future features

## Run
1. Install Flutter.
2. Extract this project.
3. Run `flutter pub get`
4. Run `flutter run`
